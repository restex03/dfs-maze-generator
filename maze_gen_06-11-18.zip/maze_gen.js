/** JavaScript DFS maze-generator
 * 
 * Russell Estes
 * 06-10-2018
 * 
 * This software is produced as open-source 
 * and released under the MIT License.
 * 
 **/
function init() {
		
	
	// get inputs
	var rows = document.getElementById("input_height").value;
	var cols = document.getElementById("input_width").value;
	
	// call function to generate maze
	gen_maze(rows, cols);
}


function gen_maze(rows, cols) {


	
	// cells are 30px each having left and right borders
	// of 1px each. Total maze width is then:
	maze_width = cols*32;
	
	// create fill area to insert cells,
	// then set id & class
	var maze_container = document.createElement('div');
	maze_container.setAttribute("id", "maze_container");
	
	document.body.appendChild(maze_container);	
	maze_container.style.width = maze_width + "px";
	// generate grid having rows x cols
	for (var i = 0; i < rows; i++) {
		
		// Create first row...
		var row = document.createElement('div');
		row.setAttribute("class", "row");
		maze_container.appendChild(row);
		row.style.width = maze_width + "px";

		// Fill row with cells...
		for (var j = 0; j < cols; j++) {
			var temp = document.createElement('span');
			// We want to be able to identify individual cells, 
			// so assign each an ID having form "row# col#"
			var id_string = i + " " + j;
			temp.setAttribute("id", id_string);
			temp.setAttribute("class", "cell");
			row.appendChild(temp);
		}
	}



	var target_cell_test = window.prompt("Enter cell (eg. '0 0')","5 4");
	document.getElementById(target_cell_test).innerHTML = "X";

/** Depth-first traversal
 * 
 * Steps: 
 * 
 * 	1) 	Choose a starting point in the field.
 * 	2) 	Randomly choose a wall at that point and carve 
 * 		a passage through to the adjacent cell, but only 
 * 		if the adjacent cell has not been visited yet. 
 * 		This becomes the new current cell.
 * 	3)	If all adjacent cells have been visited, back up 
 * 		to the last cell that has uncarved walls and repeat.
 * 	4) 	The algorithm ends when the process has backed all 
 * 		the way up to the starting point.
 * 
 * 	Source: 
 * 	http://weblog.jamisbuck.org/2010/12/27/maze-generation-recursive-backtracking
 **/
	
} // end gen_maze()

/** The MIT License

Copyright (c) 2011 Dominic Tarr

Permission is hereby granted, free of charge, 
to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to 
deal in the Software without restriction, including 
without limitation the rights to use, copy, modify, 
merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom 
the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice 
shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR 
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**/
